const WebSocket = require("ws"); 
const { SerialPort } = require("serialport"); // Doğru yazım

// Arduino'nun bağlı olduğu seri portun adı (örneğin COM3 veya /dev/ttyUSB0)
const ARDUINO_PORT = "/dev/ttyUSB0"; // Kendi portunuza göre güncelleyin
const BAUD_RATE = 9600; // Arduino'da belirttiğiniz baud hızı
const RECONNECT_INTERVAL = 5000; // 5 saniye

// WebSocket sunucusunu başlat
const wss = new WebSocket.Server({ port: 9090 }); // 9090 portunu kullanabilirsiniz

let arduino;
let isArduinoConnected = false;

// Bağlı WebSocket istemcilerini saklamak için bir Set
const clients = new Set();

// Arduino ile seri bağlantı başlatma fonksiyonu
function connectArduino() {
  console.log(`Arduino'ya bağlanmaya çalışılıyor: ${ARDUINO_PORT} @ ${BAUD_RATE} baud`);

  arduino = new SerialPort({ path: ARDUINO_PORT, baudRate: BAUD_RATE });

  arduino.on("open", () => {
    isArduinoConnected = true;
    console.log("Arduino seri portuna bağlandı.");
  });

  arduino.on("error", (err) => {
    isArduinoConnected = false;
    console.error("Arduino seri port hatası:", err.message);
    attemptReconnect();
  });

  arduino.on("close", () => {
    isArduinoConnected = false;
    console.warn("Arduino seri portu kapandı.");
    attemptReconnect();
  });

  arduino.on("data", (data) => {
    const dataStr = data.toString();
    console.log("Arduino'dan gelen:", dataStr);
    // Tüm bağlı WebSocket istemcilerine veriyi gönder
    for (const client of clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(dataStr);
      }
    }
  });
}

// Yeniden bağlanma denemesi
function attemptReconnect() {
  if (!isArduinoConnected) {
    console.log(`Arduino'ya yeniden bağlanmayı deniyor in ${RECONNECT_INTERVAL / 1000} saniye...`);
    setTimeout(() => {
      console.log("Arduino'ya yeniden bağlanma denemesi yapılıyor...");
      connectArduino();
    }, RECONNECT_INTERVAL);
  }
}

// İlk bağlantıyı kur
connectArduino();

// WebSocket sunucusuna yeni bir bağlantı geldiğinde
wss.on("connection", (ws) => {
  console.log("Yeni WebSocket bağlantısı.");
  clients.add(ws);

  // WebSocket üzerinden gelen veriyi Arduino'ya gönder
  ws.on("message", (message) => {
    const data = message.toString("utf-8"); // Buffer'ı metne dönüştür
    console.log("WebSocket'ten gelen:", data); // Dönüştürülen veriyi yazdır

    if (isArduinoConnected) {
      // Dönüştürülen veriyi Arduino'ya gönder
      arduino.write(data + "\n", (err) => {
        if (err) {
          console.error("Arduino'ya yazma hatası:", err.message);
        }
      });
    } else {
      console.warn("Arduino bağlı değil. Veri gönderilemiyor.");
    }
  });

  ws.on("close", () => {
    console.log("WebSocket bağlantısı kapandı.");
    clients.delete(ws);
  });

  ws.on("error", (err) => {
    console.error("WebSocket hatası:", err.message);
    clients.delete(ws);
  });
});

console.log("WebSocket sunucusu başlatıldı. Port: 9090");
