const WebSocket = require('ws');
const { RTCPeerConnection, RTCSessionDescription, RTCIceCandidate } = require('wrtc');

// Sinyalleşme sunucusunun adresi
const signalingServerUrl = "wss://4705-92-44-148-184.ngrok-free.app";

// Arduino ile iletişim için lokal WebSocket adresi
const SERIAL_PORT_URL = "ws://localhost:9090"; 
const RECONNECT_INTERVAL = 3000; // Yeniden bağlanma denemeleri arası 3 saniye

// ICE Sunucuları
const iceServers = [
  { urls: "stun:stun.relay.metered.ca:80" },
  {
    urls: "turn:global.relay.metered.ca:80",
    username: "c9e6a625e7e3839c886e3e5b",
    credential: "0qcPA5oh2RONehyV",
  },
  {
    urls: "turn:global.relay.metered.ca:443",
    username: "c9e6a625e7e3839c886e3e5b",
    credential: "0qcPA5oh2RONehyV",
  },
];

let peerConnection = new RTCPeerConnection({ iceServers });
let dataChannel;
let serialPort;

// Parmak verilerini tutmak için basit bir dizi
let fingerValues = ["-", "-", "-", "-", "-"];

// Sinyalleşme sunucusuna bağlan
const ws = new WebSocket(signalingServerUrl);

ws.on('message', async (message) => {
  const data = JSON.parse(message);
  if (data.type === "offer") {
    await peerConnection.setRemoteDescription(new RTCSessionDescription(data));
    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    ws.send(JSON.stringify(peerConnection.localDescription));
  } else if (data.type === "answer") {
    await peerConnection.setRemoteDescription(new RTCSessionDescription(data));
  } else if (data.type === "candidate") {
    await peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
  }
});

peerConnection.onicecandidate = (event) => {
  if (event.candidate) {
    ws.send(JSON.stringify({
      type: "candidate",
      candidate: event.candidate,
    }));
  }
};

const createDataChannel = () => {
  dataChannel = peerConnection.createDataChannel("chat");

  dataChannel.onmessage = (event) => {
    const fingerData = event.data.split(" "); // Gelen veriyi boşlukla ayır
    for (let i = 0; i < 5; i++) {
      fingerValues[i] = fingerData[i] || "-";
    }
    console.log("Gelen parmak verileri:", fingerValues.join(", "));

    // Verileri Arduino'ya gönder
    if (serialPort && serialPort.readyState === WebSocket.OPEN) {
      serialPort.send(event.data);
    } else {
      console.warn("SerialPort WebSocket bağlantısı açık değil. Veri gönderilemiyor.");
    }
  };
};

const startConnection = async () => {
  createDataChannel();
  const offer = await peerConnection.createOffer();
  await peerConnection.setLocalDescription(offer);
  ws.send(JSON.stringify(peerConnection.localDescription));
};

ws.on('open', startConnection);

// Arduino'ya bağlanmayı yöneten fonksiyon
function connectSerialPort() {
  if (serialPort && serialPort.readyState !== WebSocket.CLOSED) {
    serialPort.close();
  }

  serialPort = new WebSocket(SERIAL_PORT_URL);

  serialPort.on('open', () => {
    console.log("SerialPort WebSocket bağlantısı kuruldu.");
  });

  serialPort.on('message', (message) => {
    console.log("Arduino'dan gelen veri:", message.toString());
  });

  serialPort.on('close', (event) => {
    console.warn(`SerialPort WebSocket bağlantısı kapandı (Kodu: ${event.code}). Yeniden bağlanmayı deniyor...`);
    setTimeout(connectSerialPort, RECONNECT_INTERVAL);
  });

  serialPort.on('error', (err) => {
    console.error("SerialPort WebSocket hatası:", err.message);
    serialPort.close();
  });
}

// Arduino'ya ilk bağlantıyı kur
connectSerialPort();
